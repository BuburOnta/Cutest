<?php

namespace ConvertApi\Error;

class File extends Base
{
}