<?php

namespace ConvertApi\Error;

class Client extends Base
{
}