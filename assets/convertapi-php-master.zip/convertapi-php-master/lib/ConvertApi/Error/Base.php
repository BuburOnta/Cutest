<?php

namespace ConvertApi\Error;

abstract class Base extends \Exception
{
}